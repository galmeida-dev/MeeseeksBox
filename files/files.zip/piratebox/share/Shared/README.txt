
	</div>
</div>
<footer id="about">
	<div class="container">
		<p class="to-top"><a href="#header">Back to top</a></p>
		<h2>About MeeseeksBox</h2>
		<p>Inspired by pirate radio and the free culture movement, MeeseeksBox is a self-contained mobile collaboration and file sharing device. MeeseeksBox utilizes Free, Libre and Open Source software (FLOSS) to create mobile wireless file sharing networks where users can anonymously share images, video, audio, documents, and other digital content.</p>
		<p>MeeseeksBox is designed to be safe and secure. No logins are required and no user data is logged. The system is purposely not connected to the Internet in order to prevent tracking and preserve user privacy.</p>
		<small>MeeseeksBox is licensed under GPLv3.</small>
	</div>
</footer>
